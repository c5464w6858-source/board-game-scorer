// Unsubscribe link target for the weekly digest email.
// GET  ?e=<email>&t=<hmac>  -> shows a confirmation page (so email scanners that
//                              open links cannot unsubscribe anyone by accident)
// POST e=<email>&t=<hmac>   -> removes the weekly-email subscription
const crypto = require("crypto");

const page = (title, body, code = 200) => ({
  statusCode: code,
  headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" },
  body: `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title} | IncludeMe</title>
<style>body{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:#F7F6F2;color:#1A1712;margin:0;display:grid;place-items:center;min-height:100vh;padding:16px}
.c{background:#fff;border:1px solid #E1DDD3;border-radius:14px;max-width:440px;width:100%;padding:28px 24px;text-align:center}
h1{font-size:21px;margin:0 0 10px}p{font-size:15.5px;line-height:1.5;color:#514B40;margin:0 0 16px}
button{background:#0F6B5C;color:#fff;border:0;border-radius:10px;padding:13px 22px;font-size:16px;font-weight:600;cursor:pointer}
a{color:#0F6B5C}</style></head><body><main class="c">${body}</main></body></html>`
});

const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

function sign(email) {
  return crypto.createHmac("sha256", process.env.SUPABASE_SERVICE_ROLE_KEY || "").update(String(email).toLowerCase()).digest("hex");
}
function valid(email, token) {
  if (!email || !token || !process.env.SUPABASE_SERVICE_ROLE_KEY) return false;
  const a = Buffer.from(sign(email)), b = Buffer.from(String(token));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

async function rest(path, opts = {}) {
  const url = (process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL) + "/rest/v1/" + path;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  return fetch(url, { ...opts, headers: { apikey: key, Authorization: "Bearer " + key, "Content-Type": "application/json", Prefer: "return=representation", ...(opts.headers || {}) } });
}

async function unsubscribe(email) {
  const lower = email.toLowerCase();
  // 1) the subscription rows the weekly digest reads
  const r = await rest("kv?select=key,value&key=like.email_sub:*");
  if (!r.ok) throw new Error("lookup failed");
  const rows = (await r.json()).filter((x) => x.value && String(x.value.email || "").toLowerCase() === lower);
  for (const row of rows) {
    const d = await rest("kv?key=eq." + encodeURIComponent(row.key), { method: "DELETE" });
    if (!d.ok) throw new Error("delete failed");
  }
  // 2) the copy kept on the account, so the app also shows it as switched off
  const u = await rest("kv?select=key,value&key=eq." + encodeURIComponent("user:" + lower));
  if (u.ok) {
    const urow = (await u.json())[0];
    if (urow && urow.value && urow.value.emailSub) {
      const value = { ...urow.value };
      delete value.emailSub;
      await rest("kv?key=eq." + encodeURIComponent(urow.key), { method: "PATCH", body: JSON.stringify({ value }) });
    }
  }
  return rows.length;
}

exports.handler = async (event) => {
  const method = event.httpMethod;
  let email = "", token = "";
  if (method === "POST") {
    const p = new URLSearchParams(event.isBase64Encoded ? Buffer.from(event.body || "", "base64").toString() : event.body || "");
    email = p.get("e") || ""; token = p.get("t") || "";
  } else {
    const q = event.queryStringParameters || {};
    email = q.e || ""; token = q.t || "";
  }
  if (!valid(email, token)) {
    return page("Link not valid", `<h1>This link isn't valid</h1><p>It may have been copied wrongly. To stop weekly emails, open <a href="https://includeme.uk">includeme.uk</a>, go to your account and switch off weekly updates, or email <a href="mailto:hello@includeme.uk">hello@includeme.uk</a>.</p>`, 400);
  }
  if (method === "POST") {
    try {
      await unsubscribe(email);
    } catch (e) {
      return page("Something went wrong", `<h1>Something went wrong</h1><p>We couldn't update your settings. Please try again, or email <a href="mailto:hello@includeme.uk">hello@includeme.uk</a> and we'll do it for you.</p>`, 500);
    }
    return page("Unsubscribed", `<h1>You're unsubscribed</h1><p>You won't get any more weekly updates from IncludeMe. You can switch them back on any time in your account on <a href="https://includeme.uk">includeme.uk</a>.</p>`);
  }
  return page("Unsubscribe", `<h1>Stop weekly updates?</h1><p>Press the button to stop weekly emails to <b>${esc(email)}</b>.</p><form method="post"><input type="hidden" name="e" value="${esc(email)}"><input type="hidden" name="t" value="${esc(token)}"><button type="submit">Unsubscribe</button></form>`);
};
