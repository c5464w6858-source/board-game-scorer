var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/place-photo.js
var place_photo_exports = {};
__export(place_photo_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(place_photo_exports);
async function handler(event) {
  const key = process.env.GOOGLE_PLACES_API_KEY;
  const q = event.queryStringParameters && event.queryStringParameters.q || "";
  const w = event.queryStringParameters && event.queryStringParameters.w || "640";
  const json = (code, body) => ({
    statusCode: code,
    headers: { "Content-Type": "application/json", "Cache-Control": "public, max-age=86400" },
    body: JSON.stringify(body)
  });
  if (!key) return json(200, { url: null, note: "GOOGLE_PLACES_API_KEY not set" });
  if (!q) return json(400, { error: "missing q" });
  try {
    const r = await fetch("https://places.googleapis.com/v1/places:searchText", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Goog-Api-Key": key,
        "X-Goog-FieldMask": "places.id,places.photos"
      },
      body: JSON.stringify({ textQuery: q, regionCode: "GB", maxResultCount: 1 })
    });
    const data = await r.json();
    const photoName = data?.places?.[0]?.photos?.[0]?.name;
    const url = photoName ? `https://places.googleapis.com/v1/${photoName}/media?maxWidthPx=${encodeURIComponent(w)}&key=${key}` : null;
    return json(200, { url });
  } catch (e) {
    return json(200, { url: null, error: String(e) });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
